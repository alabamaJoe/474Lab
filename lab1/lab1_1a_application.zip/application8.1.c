void f3DataClear(char data[], unsigned long delay1, unsigned long delay2) {
    printf("%s", data);
    delaySec(delay1);
    system("cls");
    delaySec(delay2);
}
